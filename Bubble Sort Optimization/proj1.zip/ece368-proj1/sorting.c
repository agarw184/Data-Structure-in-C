#include <stdio.h>
#include "sorting.h"

long *Load_File (char *Filename, int *Size)
{
  FILE *file = fopen(Filename, "r");
  if (file == NULL)
    {
      printf("File does not exist\n");
      return 0;
    }
  int i;
  fscanf(file, "%d\n", Size);
  long *array = malloc(sizeof(long)* *Size);
  for (i = 0; i < *Size; i++)
    {
      fscanf(file, "%ld", array + i);
    }
  return array;

}

int Save_File (char *Filename, long *Array, int Size)
{
  FILE *file = fopen(Filename, "w");
  if (file == NULL)
    {
      printf("File does not exist\n");
      return 0;
    }
  fprintf(file, "%d\n", Size);
  int i;
  for (i = 0; i < Size; i++)
    {
      fprintf(file, "%ld\n", Array[i]);
    }
  return Size;
}

int *Seq1 (int N, int *Size)
{
  int *one = malloc(sizeof(int)*N);
  one[0] = 1;
 
  int i;
  
   for (i = 1; i < N; i++)
    {
       if(one[i] >= N)
	{
	  break;
	}    
      int p2 = 0;
      int p3 = 0;
      if (one[p2] * 2 == one[i - 1])
	{
	  p2++;
	}
      if (one[p3] * 3 == one[i - 1])
	{
	  p3++;
	}
      int u2 = one[p2] * 2;
      int u3 = one[p3] * 3;
      if (u2 < u3)
	{
	  p2++;
	  one[i] = u2;
	}
      else
	{
	  p3++;
	  one[i] = u3;
	}
       
    }
  *Size = i - 1;
  
  return one;

}

void Shell_Insertion_Sort(long *Array, int Size, double *NComp, double *NMove)
{
  int S;
  int  *S_1;
  S_1 = Seq1(Size, &S);
  int i;
  int j;
  int k;
  for (i = S - 1; i >= 0; i = i-1)
    {
     int g = S_1[i];
      for (j = g; j < Size; j++)
	{
	 long temp = Array[j];
	  k = j;
	  while (k >= g && Array[k - g] > temp)
	    {
	      (*NMove)++;
	      (*NComp)++;
	      
	      Array[k] = Array[k - g];
	      
	      k = k - g;
	    }
	  Array[k] = temp;
	  (*NMove)++;
	}
      
      
      
    }
}

int *Seq2 (int N, int *Size)
{
  int *two = malloc(sizeof(int)*N);
  int i = 0;
  while (two[i - 1] != 1)
    {
      N = N / 1.3;
      if (N == 9 || N == 10)
      {
        N = 11;
      }
      two[i] = N;
      i = i + 1;
    }
  *Size = i;
  return two;
}


void Improved_Bubble_Sort (long *Array, int Size, double *NComp, double *Nmove)
{
  int S;
  int *S_2 = Seq2(Size, &S);
  int i;
  int j;
  int k;
  for (i = 0; i < S; i = i + 1)
    {
      int g = S_2[i];
      for(j = g; j < Size; j++)
	{
	  k = j;
	  while(k >= g && Array[k - g] > Array[k])
	    {
	      
	      (*Nmove)++;
	      (*NComp)++;
	      long temp = Array[k];
	      Array[k] = Array[k - g];
	      Array[k - g] = temp;
	      k = k - g;
	    }
	    (*NComp)++;
	  
	}
    }
}


void Save_Seq1 (char *Filename, int N)
{
  int Size;
  int *S_one = Seq1(N, &Size);
  FILE * file1 = fopen(Filename, "w");
  fprintf(file1, "%d\n", N);
  int j;
  for (j = 0; j < Size; j++)
    {
      fprintf(file1, "%d\n", S_one[j]);
    }
}
  



void Save_Seq2 (char *Filename, int N)
{
  int Size;
  int *S_two = Seq2(N, &Size);
  FILE *file2 = fopen(Filename, "w");
  fprintf(file2, "%d\n", N);
  int j;
  for (j = Size - 1; j >= 0; j--)
    {
      fprintf(file2, "%d\n", S_two[j]);
    }
  
}
